<footer class="bg-white border-t border-gray-200 p-4 shadow-md mt-auto">
    <div class="flex items-center justify-center">
        <p class="text-sm text-gray-500">&copy; Gumukmas Multifarm</p>
    </div>
</footer>