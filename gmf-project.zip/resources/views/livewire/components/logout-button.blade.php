<button  wire:click="logout"
    class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 focus:outline-none">
    Logout
</button>

