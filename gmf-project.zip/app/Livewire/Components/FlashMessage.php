<?php

namespace App\Livewire\Components;

use Livewire\Component;

class FlashMessage extends Component
{
    public function render()
    {
        return view('livewire.components.flash-message');
    }
}
