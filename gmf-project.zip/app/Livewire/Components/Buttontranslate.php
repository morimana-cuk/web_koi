<?php

namespace App\Livewire\Components;

use Livewire\Component;

class Buttontranslate extends Component
{
    public function render()
    {
        return view('livewire.components.buttontranslate');
    }
}
